// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs).
    // The reason we default this to hidden is that native apps don't usually show an accessory bar, at
    // least on iOS. It's a dead giveaway that an app is using a Web View. However, it's sometimes
    // useful especially with forms, though we would prefer giving the user a little more room
    // to interact with the app.
    if (window.cordova && window.Keyboard) {
      window.Keyboard.hideKeyboardAccessoryBar(true);
    }

    if (window.StatusBar) {
      // Set the statusbar to use the default style, tweak this to
      // remove the status bar on iOS or change it to use white instead of dark colors.
      StatusBar.styleDefault();
    }
  });
})

.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider

    .state('app', {
    url: '/app',
    abstract: true,
    templateUrl: 'templates/menu.html',
    controller: 'AppCtrl'
  })

  .state('app.search', {
    url: '/search',
    views: {
      'menuContent': {
        templateUrl: 'templates/search.html'
      }
    }
  })
  .state('app.login', {
    url: '/login',
    views: {
      'menuContent': {
        templateUrl: 'templates/login.html'
      }
    }
  })


  .state('app.browse', {
      url: '/browse',
      views: {
        'menuContent': {
          templateUrl: 'templates/browse.html'
        }
      }
    })
    .state('app.ana', {
      url: '/anasayfa',
      views: {
        'menuContent': {
          templateUrl: 'templates/playlists.html',
          controller: 'PlaylistsCtrl'
        }
      }
    })
  .state('app.detaylar', {
      url: '/altdetay',
      views: {
        'menuContent': {
          templateUrl: 'templates/alt_detay.html',
          controller: 'PlaylistsCtrl'
        }
      }
    })
.state('app.mugeicin',{
  url: '/mugeanli',
  views:{
    'menuContent':{
      templateUrl: 'templates/muge_icin.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.esra',{
  url: '/esraerol',
  views:{
    'menuContent':{
      templateUrl: 'templates/es_ra.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.hakkinda',{
  url: '/hakkinda',
  views:{
    'menuContent':{
      templateUrl: 'templates/hakk_inda.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.ulas',{
  url: '/ulas',
  views:{
    'menuContent':{
      templateUrl: 'templates/ul_as.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.ziraat',{
  url: '/ziraat',
  views:{
    'menuContent':{
      templateUrl: 'templates/zir_aat.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.nihat',{
  url: '/nihat',
  views:{
    'menuContent':{
      templateUrl: 'templates/ni_hat.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.dost',{
  url: '/nihathatipogluiledostadogru',
  views:{
    'menuContent':{
      templateUrl: 'templates/do_st.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.kuran',{
  url: '/nihathatipogluilekuranvesunnet',
  views:{
    'menuContent':{
      templateUrl: 'templates/kur_an.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.anahaber',{
  url: '/atvanahaber',
  views:{
    'menuContent':{
      templateUrl: 'templates/ana_haber.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.atvhs',{
  url: '/atvdehaftasonu',
  views:{
    'menuContent':{
      templateUrl: 'templates/atv_hs.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.dizitv',{
  url: '/dizitv',
  views:{
    'menuContent':{
      templateUrl: 'templates/dizi_tv.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.gun',{
  url: '/atvgunortasi',
  views:{
    'menuContent':{
      templateUrl: 'templates/g_u_n.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.hsana',{
  url: '/hsana',
  views:{
    'menuContent':{
      templateUrl: 'templates/hs_ana.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.kahvalti',{
  url: '/kahvaltihaberleri',
  views:{
    'menuContent':{
      templateUrl: 'templates/kahv_alti.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.son',{
  url: '/sondurak',
  views:{
    'menuContent':{
      templateUrl: 'templates/s_o_n.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.yeter',{
  url: '/yeter',
  views:{
    'menuContent':{
      templateUrl: 'templates/yet_er.html',
      controller: 'PlaylistsCtrl'
    }
  }
})

.state('app.canli',{
  url: '/canli',
  views:{
    'menuContent':{
      templateUrl: 'templates/canli.html',
      controller: 'PlaylistsCtrl'
    }
  }
})

.state('app.haberler',{
  url: '/haberler',
  views:{
    'menuContent':{
      templateUrl: 'templates/haberler.html',
      controller: 'PlaylistsCtrl'
    }
  }
})

.state('app.veri',{
  url: '/politika',
  views:{
    'menuContent':{
      templateUrl: 'templates/veri.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.ayar',{
  url: '/ayar',
  views:{
    'menuContent':{
      templateUrl: 'templates/ayar.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.kim',{
  url: '/kimmilyonerolmakister',
  views:{
    'menuContent':{
      templateUrl: 'templates/k_i_m.html',
      controller: 'PlaylistsCtrl'
    }
  }
})
.state('app.yayinicin',{
  url: '/yayin',
  views:{
    'menuContent':{
      templateUrl: 'templates/yayin_icin.html',
      controller: 'PlaylistsCtrl'
    }
  }
})

//.state('app.alt_detay2',{
  //url:'/detay2/:programId',
  //views:{
    //'menuContent': {
      //templateUrl:'templates/detaylar2.html'
      //controller: 'PlaylistsCtrl'
    //}
  //}
//})

//.state('app.single',{
  //url: '/detay2/programId',
  //views:{
    //'menuContent' :{
      //templateUrl:'templates/app/muge.html'
      //controller:'PlaylistsCtrl'
    //}
  //}
//})






  .state('app.single', {
    url: '/detay/:diziId',
    views: {
      'menuContent': {
        templateUrl: 'templates/detaylar.html',
        controller: 'PlaylistsCtrl'
      }
    }
  });
  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/app/anasayfa');
});
