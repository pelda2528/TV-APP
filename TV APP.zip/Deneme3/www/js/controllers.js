angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})


.controller('PlaylistsCtrl', function($scope, $stateParams) {
  $scope.diziler = [
    { adi: 'X',bolum3:'img/3kurulus.png',bolum2:'img/2kurulus.png',bolum1:'img/1kurulus.png',kategori:'Dizi',logo:'img/kurulus.png', id: 0 },
    { adi: 'Y',bolum3:'img/3eskiya.png',bolum2:'img/2eskiya.png',bolum1:'img/1eskiya.png',kategori:'Dizi',logo:'img/eskıya.png', id: 1 },
    { adi: 'Z',bolum3:'img/3cukurova.png',bolum2:'img/2cukurova.png',bolum1:'img/1cukurova.png',kategori:'Dizi',logo:'img/cukurova.png', id: 2 },
    { adi: 'T',bolum3:'img/3hercai.png',bolum2:'img/2hercai.png',bolum1:'img/1hercai.png',kategori:'Dizi',logo:'img/hercai.png', id: 3 },
    { adi: 'W',bolum3:'img/3ben.png',bolum2:'img/2ben.png',bolum1:'img/1ben.png',kategori:'Dizi',logo:'img/ben.png', id: 4 },
    
  ];





  //$scope.programlar =[
  //{adi: 'M',kategori: 'Programlar',bolum2:'img/3muge.png',bolum1:'img/2muge.png',logo:'img/muge.png',id:0},
  //{adi: 'E',kategori: 'Programlar',bolum2:'img/3esra.png',bolum1:'img/2esra.png',logo:'img/esra.png',id:1},
  //{adi: 'K',kategori: 'Programlar',bolum2:'img/3kim.png',bolum1:'img/2kim.png',logo:'img/kim.png',id:2},
  //{adi: 'S',kategori: 'Programlar',bolum2:'img/3soru.png',bolum1:'img/2soru.png',logo:'img/soru.png',id:3},
  //{adi: 'D',kategori: 'Programlar',bolum2:'img/3dost.png',bolum1:'img/2dost.png',logo:'img/dost.png',id:4},
  //{adi: 'KS',kategori: 'Programlar',bolum2:'img/3kuran.png',bolum1:'img/2kuran.png',logo:'img/kuran.png',id:5},
  //{adi: 'DT',kategori: 'Programlar',bolum2:'img/3dizi.png',bolum1:'img/2dizi.png',logo:'img/dizi.png',id:6},
  //{adi: 'A',kategori: 'Programlar',bolum2:'img/3ana.png',bolum1:'img/2ana.png',logo:'img/anahaber.png',id:7},
  //{adi: 'G',kategori: 'Programlar',bolum2:'img/3gun.png',bolum1:'img/2gun.png',logo:'img/gun.png',id:8},
  //{adi: 'HS',kategori: 'Programlar',bolum2:'img/3haftasonu.png',bolum1:'img/2haftasonu.png',logo:'img/haftasonu.png',id:9},
  //{adi: 'AHS',kategori: 'Programlar',bolum2:'img/3atvde.png',bolum1:'img/2atvde.png',logo:'img/atvde.png',id:10},
  //{adi: 'KT',kategori: 'Programlar',bolum2:'img/3kahvalti.png',bolum1:'img/2kahvalti.png',logo:'img/kahvalti.png',id:11},
  //{adi: 'SON',kategori: 'Programlar',bolum2:'img/3son.png',bolum1:'img/2son.png',logo:'img/son.png',id:12},
  //{adi: 'Y',kategori: 'Programlar',bolum2:'img/3yeter.png',bolum1:'img/2yeter.png',logo:'img/yeter.png',id:13},
  //];  





  if($stateParams.diziId){
console.log("Gelen Id no: "+$stateParams.diziId );
console.log("Dizi adı: "+$scope.diziler[$stateParams.diziId].adi);
$scope.detayBilgi = $scope.diziler[$stateParams.diziId] ;
}

})






//.controller('detaylar2Ctrl',function($scope, $stateParams) {
 // $scope.programlar =[
  //{adi: 'M',kategori: 'Programlar',bolum2:'img/3muge.png',bolum1:'img/2muge.png',logo:'img/muge.png',id:0},
  //{adi: 'E',kategori: 'Programlar',bolum2:'img/3esra.png',bolum1:'img/2esra.png',logo:'img/esra.png',id:1},
  //{adi: 'A',kategori: 'Programlar',bolum2:'img/3ana.png',bolum1:'img/2ana.png',logo:'img/anahaber.png',id:2},
  //];
//})

//.controller('app/mugeCtrl',function($scope,$stateParams){



//});











.controller('PlaylistCtrl', function($scope, $stateParams) {
});